YetAnotherKeywords
==================

YetAnotherKeywords is MediaWiki extension (https://www.mediawiki.org/wiki/Extension:YetAnotherKeywords).
It gives users the ability to inject a <meta> keywords into the document header.

Copyright © 2008-2012 Jehy. Based on plugin by Joshua C. Lerner.

Requires MediaWiki 1.29 or newer.