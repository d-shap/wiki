<?php
/**
 *  Magic words for extension.
 */

$magicWords = [];

/** English (English) */
$magicWords['en'] = [
	'css' => [ 0, 'css' ],
];
