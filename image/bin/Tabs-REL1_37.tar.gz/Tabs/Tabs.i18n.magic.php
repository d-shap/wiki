<?php
/**
 * Internationalisation file for Tabs extension.
 *
 * @file
 * @ingroup Extensions
 */

$magicWords = [];

/** English
 * @author Pim (Joeytje50)
 */
$magicWords['en'] = [
	'tab' => [ 0, 'tab' ],
];
