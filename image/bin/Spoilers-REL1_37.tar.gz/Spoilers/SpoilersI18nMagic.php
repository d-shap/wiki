<?php
/**
 * Spoilers
 * Spoilers i18n Magic
 *
 * @author: Telshin, Developaws
 * @license: MIT https://opensource.org/licenses/MIT
 * @package: Spoilers
 * @link: http://www.mediawiki.org/wiki/Extension:Spoilers
 */
$magicWords = [];

$magicWords['en'] = [
	'spoiler' => [ 0, 'spoiler' ]
];
