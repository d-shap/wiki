-- This is invalid for mw.loadData()
return {
	[function() end] = true
}
