<?php
$magicWords = [];
$magicWords['en'] = [
	'attach' => [ 1, 'attach' ],
	'exturl' => [ 1, 'exturl' ],
	'fileprefix' => [1, 'FILEPREFIX'],
	'attachments ignore subpages' => [1, 'attachments ignore subpages']
];
