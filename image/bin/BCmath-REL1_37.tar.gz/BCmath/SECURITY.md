# Security

[MediaWiki](https://mediawiki.org) takes security very seriously, so also this extension. If you believe you have found a security issue in Mediawiki itself, see [Reporting security bugs](https://www.mediawiki.org/wiki/Reporting_security_bugs) for information on how to responsibly report it.

If you believe you have found a security bug in the extension, please email the extension creator.
