# Code of Conduct

The development of this software within Wikimedia spaces are covered by a [Code of Conduct](https://www.mediawiki.org/wiki/Special:MyLanguage/Code_of_Conduct).

Note that main development of the [BCmath extension](https://www.mediawiki.org/wiki/Special:MyLanguage/Extension:BCmath) extension is outside Wikimedia, at [GitHub](https://github.com/jeblad/BCmath/) and [TranslateWiki](https://translatewiki.net/wiki/Special:Translate/mwgithub-bcmath), and thus not covered by this policy. It should although be taken as good advice. On Wikimedia spaces, like Gerrit, it is in effect.
