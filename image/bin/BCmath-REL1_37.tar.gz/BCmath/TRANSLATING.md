# Translating

This extension is translated at [TranslateWiki](https://translatewiki.net/wiki/Special:Translate/mwgithub-bcmath).

Some messages are special markers, and should not be translated. It may still be necessary to adapt them somehow, and in those cases special care must be taken to not disturb normal parsing.
