-- Load and return the lib 'as-is'
return require 'expect'
