<?php
/**
 *  Magic words for extension.
 */

$magicWords = [];

/** English (English) */
$magicWords['en'] = [
	'switchtablink' => [ 0, 'switchtablink' ],
];
